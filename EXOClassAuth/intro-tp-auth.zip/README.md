## Base de données

users

- id 
- username
- password
- role (admin ou user)